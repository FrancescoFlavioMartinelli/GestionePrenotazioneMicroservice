package runnable;

import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
@Order(1)
public class UtenteRunnable implements CommandLineRunner {
//@Autowired
//	UtenteRepository ur;
	@Override
	public void run(String... args) throws Exception {
//		System.out.println("UTENTE RUNS");
//		
//		Utente u = new Utente();
//		
//		ur.save(u);
		
		
	}

	
}
