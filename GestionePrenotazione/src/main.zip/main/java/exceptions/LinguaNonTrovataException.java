package exceptions;

public class LinguaNonTrovataException extends Exception {

	public LinguaNonTrovataException() {
		super("Lingua non trovata");
	}
}
