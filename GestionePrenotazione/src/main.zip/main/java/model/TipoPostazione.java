package model;

public enum TipoPostazione {
	PRIVATO,
	OPENSPACE,
	SALA_RIUNIONI
}
