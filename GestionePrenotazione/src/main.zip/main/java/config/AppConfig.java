package config;

import org.springframework.context.annotation.Bean;

import model.Edificio;

public class AppConfig {

//	@Autowired
//	EdificioRepositoru er;
//	
//	@Bean
//	public Edificio getEdificioA() {
//		Edificio e = new Edificio();
//		e.setCitta(null);
//		e.setIndirizzo("test");
//		er.save(e);
//		return e;
//		
//	}
}
